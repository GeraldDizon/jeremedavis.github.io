<?php
    include('../Connection/Connect.php');

    // Create connection
    // Check connection


    $page =isset($_GET['page'])? $_GET['page'] : 1 ;

    if($page == "" || $page == "1"){
        $page1 = 0;
    } else {
        $page1 = ($page*5)-5;
    }
    


    $sql = "SELECT id, Image, 3dLink, Name, Type, Price, Description, Featured, Carousel FROM product  ORDER BY id DESC LIMIT $page1,5";
    $query = $conn->prepare($sql);
    $executed = $query->execute();
    $rows = array();
    while ($row = $query->fetch(PDO::FETCH_ASSOC)){
        $rows[] = $row;
    }



    $sql = "SELECT id, Image, 3dLink, Name, Type, Price, Description, Featured, Carousel FROM product  ORDER BY id DESC";
    $query = $conn->prepare($sql);
    $executed = $query->execute();
    $rowCount = $query->rowCount();
?>