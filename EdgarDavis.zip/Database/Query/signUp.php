<?php
require("../Connection/Connect.php");
if(isset($_POST['signUp'])){
try {

    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    // set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
}catch(PDOException $e) {
echo "Error: " . $e->getMessage();
}


    //Get data from input type boxes
    $Name = $_POST['name'];
    $EmailAddress = $_POST['email'];
    $ContactNumber = $_POST['contact'];
    $Password = $_POST['password'];
    $ConfirmPassword = $_POST['ConfirmPassword'];


    //Check for existing email.
    $sql = "SELECT EmailAddress FROM user WHERE EmailAddress = :EmailAddress";
    $query = $conn->prepare($sql);
    $stmt = $query->execute(array(":EmailAddress"=>$EmailAddress));




//Form Validation
    if(empty($_POST) === false){
        $errorsSignUp = array();

            if(empty($Name) == true || empty($EmailAddress) == true || empty($ContactNumber) == true || empty($Password) == true){
            $errorsSignUp[] = "Please don't leave a blank";
            }

            if(ctype_alpha($Name) === false){
                if (!ctype_alpha(str_replace(' ', '', $Name))){
                    $errorsSignUp[] = "Name must only Contain Letters";
                }
            }

            if(filter_var($EmailAddress, FILTER_VALIDATE_EMAIL) === false){
                $errorsSignUp[] = "Thats not a valid Email Address";  
            }

            if($row = $query->fetch(PDO::FETCH_ASSOC)){
                $errorsSignUp[] = "Email Address already in use";   
             }

            if(ctype_digit($ContactNumber) === false){
                $errorsSignUp[] = "Invalid Contact Number";
            }

            if($ConfirmPassword != $Password){
                $errorsSignUp[] = "Password does not match";
            }   


    else{
        if(empty($errorsSignUp) === true){
                // prepare sql and bind parameters
                $verify = 'Pending';
                $sql = "INSERT INTO user (Name, EmailAddress, ContactNumber, Password, Status) VALUES (?, ?, ?, ?, ?)";
                $query = $conn->prepare($sql);
                $stmt = $query->execute(array($Name,$EmailAddress,$ContactNumber,$Password, $verify));

                if($stmt){
    //Check if post are empty or input type data are not gathered.
                        $sql = "SELECT * FROM user WHERE EmailAddress = :EmailAddress";
                        $query_view = $conn->prepare($sql);
                        $stmt = $query_view->execute(array(":EmailAddress"=>$EmailAddress));

                        if($row = $query_view->fetch(PDO::FETCH_ASSOC)){
                        //Session Set variable = Set Database Column Name
                        $_SESSION['idbase'] = $row['id'];
                        $_SESSION['fullname'] = $row['Name'];
                        $_SESSION['Email'] = $row['EmailAddress'];
                        $_SESSION['contact'] = $row ['ContactNumber'];
                        $_SESSION['status'] = $row ['Status'];
                        require('../phpmailer/EmailVerification.php');
                        //Send Verification Email


                        //Load composer's autoloader

                                    
                    }

                }
        
        }
    }
}
}


?>