        function totalamount() {
            var q = 0;
            
            
            var rows = document.getElementById('myTable').getElementsByTagName("tbody")[0].getElementsByTagName("tr").length;
            
            for( var i = 0; i < rows; i++ ){
                var z = $('.amount:eq(' + i + ')').html();
                
                if (!isNaN(z)) {
                    q +=Number(z);
                }
            }
            $('.total').html(q);
        }

        $(function () {
            $('.body').delegate('.product_quantities','change',function(){
                var tr = $(this).parent().parent();
                var qty = tr.find('.product_quantities option:selected').attr('value');
                var price = tr.data('price');

                var total = (price * qty);
                tr.find('.amount').html(total);
                totalamount()
            });
        });