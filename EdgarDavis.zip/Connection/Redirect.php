<?php
	if(!isset($_SESSION['Email'])){
		header("Location: ../Public/Account.php");
	}
	else{

	}
?>