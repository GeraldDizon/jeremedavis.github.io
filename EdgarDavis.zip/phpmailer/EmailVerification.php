<?php 
    session_start();
    use PHPMailer\PHPMailer\PHPMailer;
    use PHPMailer\PHPMailer\Exception;
    require 'vendor/autoload.php';

    $id = $_SESSION['idbase'];
    $name = $_SESSION['fullname'];
    $email = $_SESSION['Email'];

    $mail = new PHPMailer;  

    $mail->isSMTP();
    $mail->SMTPAuth = true;

    $mail->Host = 'smtp.gmail.com';
    $mail->Username = '09086959226';
    $mail->SMTPSecure = 'ssl';
    $mail->Port = 465;

    $mail->From = 'jeremedavis84@gmail.com';
    $mail->FromName = 'Jereme Davis';
    $mail->addAddress($email, $name);

    $mail->Subject = 'Verify your email address';
    $mail->Body = "Please confirm that you want to use this as your Edgar Davis account email address." . "<a href='jeremedavis84.xyz/EdgarDavis/Database/Query/Verified.php?id=$id'>Verify your email</a>";
    $mail->AltBody = 'Please confirm that you want to use this as your Edgar Davis account email address.';
    if($mail->send()){
        header("Location: ../Public/Profile.php");
    }
?>